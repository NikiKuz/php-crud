<?php 
include_once $dbPath . 'db.php';
include_once $secPath . 'token.php'; // Подключаем защиту от CSRF

// Проверяем, передан ли ID пользователя
if (!isset($_GET['id'])) {
    die("User ID is missing.");
}

$userId = $_GET['id'];
$user = getById('users', $userId); // Получаем данные пользователя

if (!$user) {
    die("User not found.");
}

// Если форма отправлена, обрабатываем удаление
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['token']) || !validateToken($_POST['token'])) {
        die("Invalid CSRF token.");
    }

    delete('users', $userId); // Удаляем пользователя
    header("Location: /?app=$app&view=list"); // Перенаправляем на список
    exit();
}
?>

<h2>Delete User</h2>
<p>Are you sure you want to delete user <strong><?= htmlspecialchars($user['username']); ?></strong>?</p>

<form action="" method="post" onsubmit="return confirm('Are you sure you want to delete this user?');">
    <!-- CSRF-токен -->
    <input type="hidden" name="token" value="<?= generateToken(); ?>">
    <button type="submit">Delete</button>
</form>

<a href="/?app=users&view=list">Cancel</a> <!-- Кнопка "Отмена" -->