<?php 

include_once $dbPath .  'db.php';
//include_once $secPath . 'token.php';
//include_once $secPath . 'submit.php';

// Отладочный код, чтобы посмотреть содержимое GET и POST запросов.

// echo "<h2>GET запрос</h2>"; 
// var_dump($_GET);
// echo "<hr2>";

// echo "<h2>POST запрос</h2>";
// var_dump($_POST);
// echo "<hr2>";

if(!empty($_POST)){
  $name = $_POST['name'];
  $review = $_POST['review'];
  $rate = $_POST['rate'];
  $id = create('reviews', [
    'name' => $name,
    'review' => $review,
    'rate' => $rate
  ]);
  if($id){
    echo 'Review created'; // Вместо вывода сообщения лушче сделать перенаправление на страницу с созданной записью или списком всех записей. 
    // Подумайте, как это сделать. 
    header("Location: /?app=$app&view=list");
  }
  else{
    echo 'Error';
    // Здесь также можно перенаправить на страницу ошибки. Подумайте, как это сделать. 
  }
}
?>
<h2>
  Create Review
</h2>

<form action="" class="form" method="post">
  
  <div class="form__field">
    <label for="name" class="form__label">
      Name:
    </label>
    <input type="text" id="name" name="name" class="form__input">
  </div>
  <div class="form__field">
    <label for="review" class="form__label">
      Review:
    </label>
    <textarea id="review" name="review" rows="10" cols="70"> </textarea>
  </div>
  <div class="form__field">
    <label for="rate" class="form__label">
     rate:
    </label>
    <input type="number" id="rate" name="rate" class="form__input">
  </div>
  <button type="submit">Send</button>
</form>