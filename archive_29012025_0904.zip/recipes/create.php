<?php 

include_once $dbPath .  'db.php';
//include_once $secPath . 'token.php';
//include_once $secPath . 'submit.php';

// Отладочный код, чтобы посмотреть содержимое GET и POST запросов.

// echo "<h2>GET запрос</h2>"; 
// var_dump($_GET);
// echo "<hr2>";

// echo "<h2>POST запрос</h2>";
// var_dump($_POST);
// echo "<hr2>";

if(!empty($_POST)){
  $title = $_POST['title'];
  $description = $_POST['description'];
  $kcal = $_POST['kcal'];
  $id = create('recipes', [
    'title' => $title,
    'description' => $description,
    'kcal' => $kcal
  ]);
  if($id){
    //echo 'Recipe created'; // Вместо вывода сообщения лушче сделать перенаправление на страницу с созданной записью или списком всех записей. 
    // Подумайте, как это сделать. 
    header("Location: /?app=$app&view=list");
    exit;
  }
  else{
    echo 'Error';
    // Здесь также можно перенаправить на страницу ошибки. Подумайте, как это сделать. 
  }
}
?>
<h2>
  Create Recipe
</h2>

<form action="" class="form" method="post">
  
  <div class="form__field">
    <label for="title" class="form__label">
      Ttle:
    </label>
    <input type="text" id="title" name="title" class="form__input">
  </div>
  <div class="form__field">
    <label for="description" class="form__label">
      Description:
    </label>
    <textarea id="description" name="description" rows="10" cols="70"> </textarea>
  </div>
  <div class="form__field">
    <label for="kcal" class="form__label">
      Calories:
    </label>
    <input type="number" id="kcal" name="kcal" class="form__input">
  </div>
  <button type="submit">Create Recipe</button>
</form>